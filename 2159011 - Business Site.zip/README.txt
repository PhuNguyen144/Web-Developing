2159011 - Nguyễn Ngọc Phú

Main and login site: https://www.minecraft.net/en-us

Note: For the <i> tag, i do not know how it does not work properly, sometime it does, sometime it does not. I try to fix - add the font awesome link, read the docs, ask on StackOverFloat àn GitHub, it does not work either.